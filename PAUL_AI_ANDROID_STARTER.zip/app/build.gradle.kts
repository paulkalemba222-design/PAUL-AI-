plugins {
 id("com.android.application")
 id("org.jetbrains.kotlin.android")
}
android {
 namespace = "ai.paul.app"
 compileSdk = 35
 defaultConfig {
  applicationId = "ai.paul.app"
  minSdk = 26
  targetSdk = 35
  versionCode = 1
  versionName = "0.1.0"
 }
}
