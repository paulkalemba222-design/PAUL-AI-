# PAUL AI Android — starter v0.1

Ce ZIP contient un projet Android source : interface chat, entrée vocale Android, sélection de fichiers, appel au backend Supabase `paul-ai`.

## Limites importantes
- Ce ZIP est du code source, pas un APK compilé.
- Le backend Supabase actuel utilise `verify_jwt=true`. Cette première version ne possède pas encore l'écran de connexion Supabase. Si l'API renvoie 401, il faut intégrer Auth avant que le chat fonctionne.
- Les fichiers TXT/MD/CSV/JSON peuvent être lus et ajoutés au message. PDF/images ne sont pas encore analysés par le modèle.
- La clé `sb_publishable_...` est une clé publique client. N'ajoutez jamais de clé OpenRouter, `service_role` ou autre secret dans l'application.
- La reconnaissance vocale utilise le service Android disponible sur l'appareil.

## Créer l'APK gratuitement avec GitHub Actions
1. Crée un dépôt GitHub `paul-ai-android`.
2. Décompresse le ZIP et envoie tous les fichiers dans le dépôt.
3. Ouvre **Actions** → **Build PAUL AI APK**.
4. Appuie sur **Run workflow**.
5. Télécharge l'artefact `PAUL-AI-debug-APK` quand le workflow finit.

C'est un APK de test debug, pas encore un APK signé pour publication. Prochaine étape : intégrer Supabase Auth, puis traitement PDF/images et lecture vocale des réponses.
